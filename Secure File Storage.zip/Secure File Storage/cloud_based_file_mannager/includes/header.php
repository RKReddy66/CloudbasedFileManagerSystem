<?php
	ini_set("display_errors",1);
	error_reporting(E_ERROR);
	session_start();
	include_once("includes/db_connect.php");
	include_once("includes/functions.php");
?>
<<!DOCTYPE html>
<html lang="en">
<head>
	<title>AWS Cloud File Manager</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
	<script type="text/javascript" src="js/jquery-1.6.js" ></script>
</head>
<body id="page1">
<div class="bg1">
  <div class="bg2">
    <div class="main">
      <!-- header -->
      <header>
        <h1 style="margin-top: 55px; padding: 0px;"><a href="index.html" style="font-size: 43px; text-decoration: none; color: #FFF;">Secure File Manager</a></h1>
        <div class="department"> 9863 - 9867 Mill Road, LA, MG09 99HT<br>
          <span>Freephone: &nbsp; +1 800 559 6580</span> </div>
      </header>
      <div class="box">
        <nav>
          <ul id="menu">
			<li class="active"><a href="index.php" id="home_page">Home</a></li>
			<li><a href="about.php" id="about">About</a></li>
			<li><a href="services.php" id="service">Features</a></li>
      <?php if($_SESSION['user_details']['user_level_id'] == 1) {?>
			  <li><a href="filemanager.php" id="filemanager">Filemanager</a></li>
      <?php } else if($_SESSION['login'] != 1) {?>
        <li><a href="login.php" id="login">Login</a></li>
      <?php } ?>
            <li><a href="contact.php" id="locations">Contact Us</a></li>
            <?php if($_SESSION['user_details']['user_level_id'] == 1) {?>
        <li><a href="./lib/login.php?act=logout">Logout</a></li>
      <?php } ?>
          </ul>
        </nav>
        <!-- header end -->
        <div id="div_content">