
<?php include_once("includes/header.php"); ?> 
<article id="content">
  <div class="box1">
    <div class="wrapper">
      <form action="#" id="form1" style="margin-top:65px">
          <img src="images/side.jpeg" alt="">
      </form>
      <div class="col2 pad">
        <h2><img src="images/title_marker1.jpg" alt="">About Project</h2>
        <div class="wrapper pad_bot2">
          <figure class="left marg_right1"><img src="images/page2_img1.png" alt="" style="width:190px; height:150px"></figure>
          <p class="pad_bot1"><strong class="color3">About AWS Based Secure File Management</strong><br>
          A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons.
          Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server (connecting and accessing the server's file system like a local file system) or by providing its own full client implementations for file server protocols.
          Orthodox file managers are among the most portable file managers. Examples are available on almost any platform, with both command-line and graphical interfaces. This is unusual among command line managers in that something purporting to be a standard for the interface is published. They are also actively supported by developers. This makes it possible to do the same work on different platforms without much relearning of the interface.


          </div>
    </div>
  </div>
</article>
<!--content end-->
<?php include_once("includes/footer.php"); ?> 