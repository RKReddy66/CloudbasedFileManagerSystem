<?php include_once("includes/header.php"); ?> 
<!-- content -->
<article id="content">
  <div class="box1">
    <div class="wrapper">
      <form action="#" id="form1" style="margin-top:65px">
        <fieldset>
          <img src="images/side.jpeg" alt="">
        </fieldset>
      </form>
      <div class="col2 pad">
        <h2><img src="images/title_marker1.jpg" alt="">Contact Form</h2>
        <form id="ContactForm" action="#">
          <div>
            <div  class="wrapper">
              <input type="text" class="input">
              Name: </div>
            <div  class="wrapper">
              <input type="text" class="input">
              Address: </div>
            <div  class="wrapper">
              <input type="text" class="input">
              Email: </div>
            <div  class="textarea_box">
              <textarea name="textarea" cols="1" rows="10" class="input" style="height: 200px;"></textarea>
              Contacts: </div>
            <a href="#" class="button2">Send</a> <a href="#" class="button2">Clear</a> </div>
        </form>
      </div>
    </div>
  </div>
  <div class="pad">
    <h2>Our Contacts</h2>
    <div class="line2">
      <div class="wrapper line3">
        <div class="col1">
          <p class="pad_bot1"><strong class="color2">USA</strong></p>
          <p class="pad_bot1">8901 Marmora Road, Glasgow, D04</p>
          <p class="cols"> Freephone:<br>
            Telephone:<br>
            Fax:<br>
            Email:</p>
          +1 800 559 6580<br>
          +1 800 603 6035<br>
          +1 800 889 9898<br>
          <a href="#" class="color1">mail@demolink.org</a> </div>
        <div class="col1 pad_left1">
          <p class="pad_bot1"><strong class="color2">Canada</strong></p>
          <p class="pad_bot1">8901 Marmora Road, Glasgow, D04</p>
          <p class="cols"> Freephone:<br>
            Telephone:<br>
            Fax:<br>
            Email:</p>
          +1 800 559 6580<br>
          +1 800 603 6035<br>
          +1 800 889 9898<br>
          <a href="#" class="color1">mail@demolink.org</a> </div>
        <div class="col1 pad_left1">
          <p class="pad_bot1"><strong class="color2">Mexico</strong></p>
          <p class="pad_bot1">8901 Marmora Road, Glasgow, D04</p>
          <p class="cols"> Freephone:<br>
            Telephone:<br>
            Fax:<br>
            Email:</p>
          +1 800 559 6580<br>
          +1 800 603 6035<br>
          +1 800 889 9898<br>
          <a href="#" class="color1">mail@demolink.org</a> </div>
      </div>
    </div>
  </div>
</article>
<!--content end-->