
<?php include_once("includes/header.php"); ?> 
<article id="content">
  <div class="box1">
    <div class="wrapper">
      <form action="#" id="form1" style="margin-top:65px">
        <fieldset>
          <img src="images/side.jpeg" alt="">
        </fieldset>
      </form>
      <div class="col2 pad">
        <h2><img src="images/title_marker1.jpg" alt="">Login to Your Account</h2>
        <form id="ContactForm" action="lib/login.php" method="post">
        <div class='msg'><?=$_REQUEST['msg']?></div>
          <table style="font-size: 15px;" cellpadding=10>
            <tr>
              <td style="width: 40%;">Username</td>
              <td style="width: 60%;"><input type="text" name="user_user" class="input" required></td>
            </tr>
            <tr>
              <td>Password</td>
              <td><input type="password" name="user_password" class="input" required></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><br><input type="submit" value="Submit" class="button2"><input style="margin-left: 10px" type="reset" value="Reset" class="button2"> </td>
            </tr>
          </table>
           </div>
           <input type="hidden" name="act" value="check_login">
        </form>
      </div>
    </div>
  </div>
</article>
<?php include_once("includes/footer.php"); ?> 