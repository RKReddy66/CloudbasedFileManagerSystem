<?php include_once("includes/header.php"); ?> 
 <article id="content">
    <div class="box1">
      <div class="wrapper">
        <div>
          <ul>
            <li><img src="images/banner.jpg" alt=""></li>
          </ul>
        </div>
      </div>
      <div class="pad">
        <div class="line1">
          <div class="wrapper line2">
            <div class="col1">
              <h2><img src="images/title_marker1.jpg" alt="">AWS Cloud Enabled</h2>
              <p class="pad_bot1">Cloud storage services may be accessed through a colocated cloud computing service, a web service application programming interface (API) or by applications that utilize the API, such as cloud desktop storage, a cloud storage gateway or Web-based content management systems.</p>
              <a href="#" class="color1">Read More</a> </div>
            <div class="col1 pad_left1">
              <h2><img src="images/title_marker2.jpg" alt="">Secure File Transfer</h2>
              <p class="pad_bot1">A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying.</p>
              <a href="#" class="color1">Read More</a> </div>
            <div class="col1 pad_left1">
              <h2><img src="images/title_marker3.jpg" alt="">File Manager Client</h2>
              <p class="pad_bot1">Cloud storage is a model of computer data storage in which the digital data is stored in logical pools, said to be on "the cloud". The physical storage spans multiple servers (sometimes in multiple locations), and the physical environment is typically owned and managed by a hosting company.</p>
              <a href="#" class="color1">Read More</a> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="pad">
      <div class="wrapper line3">
        <div class="col2" style="tex-align: justify; width: 95%">
          <h2>Welcome to AWS Secure File Manager!</h2>
          <p class="pad_bot1"><strong class="color2">AWS Enabled secure file storage and transfer system</strong><br>
          <p class="pad_bot2">A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons. Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server (connecting and accessing the server's file system like a local file system) or by providing its own full client implementations for file server protocols. Orthodox file managers are among the most portable file managers. Examples are available on almost any platform, with both command-line and graphical interfaces. This is unusual among command line managers in that something purporting to be a standard for the interface is published. They are also actively supported by developers. This makes it possible to do the same work on different platforms without much relearning of the interface. A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying. sCloud storage services may be accessed through a colocated cloud computing service, a web service application programming interface (API) or by applications that utilize the API, such as cloud desktop storage, a cloud storage gateway or Web-based content management systems.</p>
          <a href="#" class="button1">Read More</a> </div>
    </div>
  </article>
  <?php include_once("includes/footer.php"); ?> 