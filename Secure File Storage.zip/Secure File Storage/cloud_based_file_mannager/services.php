<?php include_once("includes/header.php"); ?> 
<article id="content">
  <div class="box1">
     <div class="wrapper">
        <div class="pad">
           <h2><img src="images/title_marker1.jpg" alt="">Project Features</h2>
           <div class="wrapper pad_bot2">
              <figure class="left marg_right1"><img src="images/page2_img1.png" alt="" style="width: 200px; height: 150px"></figure>
              <p class="pad_bot1"><strong class="color3">AWS Enabled Cloud Storage</strong><br>
              A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons. Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server.
              </p>
           </div>
           <div class="wrapper">
              <figure class="left marg_right1"><img src="images/side.jpeg" alt="" style="width: 200px; height: 150px"></figure>
              <p class="pad_bot1"><strong class="color3">Secure File Manager</strong><br>
              A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons. Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server.
              </p>
           </div>
           <div class="wrapper pad_bot2">
              <figure class="left marg_right1"><img src="images/side2.jpg" style="width: 200px; height: 150px" alt=""></figure>
              <p class="pad_bot1"><strong class="color3">Integrated with Web UI</strong><br>
              A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons. Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server.
              </p>
           </div>
           <div class="wrapper">
              <figure class="left marg_right1"><img src="images/side3.jpg" style="width: 200px; height: 150px" alt=""></figure>
              <p class="pad_bot1"><strong class="color3">High Level of security</strong><br>
              A file manager or file browser is a computer program that provides a user interface to manage files and folders. The most common operations performed on files or groups of files include creating, opening (e.g. viewing, playing, editing or printing), renaming, moving or copying, deleting and searching for files, as well as modifying file attributes, properties and file permissions. Folders and files may be displayed in a hierarchical tree based on their directory structure. Some file managers contain features inspired by web browsers, including forward and back navigational buttons. Some file managers provide network connectivity via protocols, such as FTP, HTTP, NFS, SMB or WebDAV. This is achieved by allowing the user to browse for a file server.
              </p>
           </div>
        </div>
     </div>
  </div>
</article>
<?php include_once("includes/footer.php"); ?> 