<?php include_once("includes/header.php"); ?> 
    <link rel="stylesheet" href="css/afm.css">
    <link rel="stylesheet" href="plugins/fontawesome/css/all.css">
    <link rel="stylesheet" type="text/css" href="plugins/DataTables/DataTables-1.10.18/css/jquery.datatables.min.css" />
    <link rel="stylesheet" type="text/css" href="plugins/DataTables/Select-1.2.6/css/select.dataTables.min.css" />
    <link rel="stylesheet" type="text/css" href="plugins/contextMenu/jquery.contextMenu.min.css">
    <link rel="stylesheet" type="text/css" href="plugins/dropzone/min/dropzone.min.css">
    <article id="content">
  <div class="box1">
    <div class="wrapper">
    <div class="col2 pad" style="width: 95%">
    <h2><img src="images/title_marker1.jpg" alt="">Secure File Manager Control Panel</h2>

    <div id="afm-body">
        <div id="afm-loading">
            <div class="afm-ring-2">
                <div class="afm-ball-holder">
                    <div class="afm-ball"></div>
                </div>
            </div>
        </div>
        <ul class="afm-new" id="afm-rename">
            <li>
                <span>Name:</span>
                <input type="text" name="name" id="new_name" autocomplete="off">
                <button class="afm-button" type="button" onclick="rename()">Confirm</button>
            </li>
            <div class="afm-new-close" onclick="closeRename()"><i class="fas fa-times"></i></div>
        </ul>
        <div id="afm-toolbar">
            <div class="afm-toolbar-item" onclick="back()">
                <i class="fas fa-arrow-left"></i>
            </div>
            <div class="afm-toolbar-item afm-toolbar-arrow" onclick="forward()">
                <i class="fas fa-arrow-right"></i>
            </div>
            <div class="afm-toolbar-item" onclick="openNewFolder()">
                <img src="img/icons/icons8-new-folder.png" />
                <span>New Folder</span>
            </div>
            <ul class="afm-new" id="afm-new-folder">
                <li>
                    <span>Name:</span>
                    <input type="text" name="folder" id="new_folder" autocomplete="off">
                    <button class="afm-button" type="button" onclick="newFolder()">Confirm</button>
                </li>
                <div class="afm-new-close" onclick="closeNewFolder()"><i class="fas fa-times"></i></div>
            </ul>
            <div class="afm-toolbar-item" onclick="download()">
                <img src="img/icons/icons8-download.png" />
                <span>Download</span>
            </div>
            <div class="afm-toolbar-item" onclick="openUpload()">
                <img src="img/icons/icons8-upload.png" />
                <span>Upload</span>
            </div>
            <div class="afm-toolbar-item afm-right" onclick="toggleViewSquare()">
                <i class="fas fa-th"></i>
            </div>
            <div class="afm-toolbar-item afm-right" onclick="toggleViewList()">
                <i class="fas fa-th-list"></i>
            </div>
        </div>
        <div id="afm-sidebar">
            <div class="afm-sidebar-item" data-file-path="root">
                <img src="img/icons/icons8-folder.png" />
                <span>Home</span>
            </div>
        </div>
        <div id="afm-content">
            <div id="afm-dropzone">
                <i class="fas fa-times afm-right afm-dz-close" onclick="closeUpload()"></i>
                <form action="http://127.0.0.1/cloud_based_file_mannager/api/upload.php" class="dropzone needsclick" id="dz-upload">
                    <span id="tmp-path"></span>
                    <div class="dz-message needsclick">
                        <span class="text">
                                <i class="fas fa-file-upload"></i>
                            Drop files here or click to upload.
                            </span>
                        <span class="plus">+</span>
                    </div>
                </form>
            </div>
            <div id="afm-square">
            </div>
            <table id="file-list" class="hover row-border">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Size</th>
                    </tr>
                </thead>
                <tbody id="afm-file-body">
                </tbody>
            </table>
        </div>
    </div>
<script type="text/javascript" src="plugins/jquery/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="plugins/DataTables/DataTables-1.10.18/js/jquery.datatables.min.js"></script>
<script type="text/javascript" src="plugins/DataTables/Select-1.2.6/js/dataTables.select.min.js"></script>
<script type="text/javascript" src="plugins/contextMenu/jquery.contextMenu.min.js"></script>
<script type="text/javascript" src="plugins/contextMenu/jquery.ui.position.min.js"></script>
<script type="text/javascript" src="plugins/dropzone/min/dropzone.min.js"></script>
<script type="text/javascript" src="js/afm.js"></script>
</div>
    </div>
  </div>
</article>
<?php include_once("includes/footer.php"); ?> 